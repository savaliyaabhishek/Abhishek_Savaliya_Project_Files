#include <at89c5131.h>
#include "lcd.h"
#include "serial.c"


unsigned int q[4]={8,6,4,4};
unsigned char i1, i2, i3, i4;
void issue();
void ret();
	
void main(void){
	unsigned char ch = 0;
  uart_init(); 
  while (1)
  {
    transmit_string("Micro-controllers available: 8051-");
		i1=48+q[0];
		transmit_char(i1);
		transmit_string("TIVA-");
		i2=48+q[1];
		transmit_char(i2);
		transmit_string("AT328-");
		i3=48+q[2];
		transmit_char(i2);
		transmit_string("STM32-");
		i4=48+q[3];
		transmit_char(i2);
		transmit_string("/r/n");
		transmit_string("Press I for Issue and R for Return /r/n");
    ch = receive_char();

    switch (ch)
    {
    case 'i':
      issue();
      break;

    case 'r':
      ret();
      break;

    default:
      continue;
    }
  }
}

void issue(){
	unsigned char ch1 = 0;
	unsigned char ch2 = 0;
  unsigned char index = 0;
	transmit_string("Enter micro-controller to be borrowed");
	ch1 = receive_char();

  switch (ch1)
  {
  case '1':
    index = 0;
    break;

  case '2':
    index = 1;
    break;
  
	case '3':
    index = 2;
    break;
	
	case '4':
    index = 3;
    break;
	
  default:
    transmit_string("Requested micro-controller not available...\r\n");
    return;
  }
	transmit_string("Enter Quantity:");
	ch2 = receive_char();
	q[index]=q[index] - (ch2 - 48);
	if(q[index] < 0 ){
		transmit_string("Requested micro-controller not available...\r\n");
	}
	
	
}

void ret(){
	unsigned char ch1 = 0;
	unsigned char ch2 = 0;
  unsigned char index = 0;
	transmit_string("Enter micro-controller to be returned");
	ch1 = receive_char();

  switch (ch1)
  {
  case '1':
    index = 0;
    break;

  case '2':
    index = 1;
    break;
  
	case '3':
    index = 2;
    break;
	
	case '4':
    index = 3;
    break;
	
  default:
    transmit_string("You can�t return what you don�t have...\r\n");
    return;
  }
	transmit_string("Enter Quantity:");
	ch2 = receive_char();
	q[index]=q[index] + ch2 - 48;
	transmit_string("Returned micro-controller received!\r\n");
	
}