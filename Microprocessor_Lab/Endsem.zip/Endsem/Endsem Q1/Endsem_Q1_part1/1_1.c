#include <at89c5131.h>
#include "lcd.h"
#include <stdio.h>


long unsigned int c,a1,a0,b1,b0,c1,c0,c2,c3,count;
unsigned char str[9],str2[5];
long unsigned int a=29851;
long unsigned int b=11237;

void int_to_string9(unsigned int val,unsigned char *temp_str_data)
{	
   
		temp_str_data[0]=48+(val/1000000000);
	  temp_str_data[1]=48+((val%100000000)/10000000);
	  temp_str_data[2]=48+((val%10000000)/1000000);
	  temp_str_data[3]=48+((val%1000000)/100000);
	  temp_str_data[4]=48+((val%100000)/10000);
	  temp_str_data[5]=48+((val%10000)/1000);
	  temp_str_data[6]=48+((val%1000)/100);
	  temp_str_data[7]=48+((val%100)/10);
	  temp_str_data[8]=48+(val%10);
}
void int_to_string5(unsigned int val,unsigned char *temp_str_data)
{	
   
	  temp_str_data[0]=48+(val/100000);
	  temp_str_data[1]=48+((val%10000)/1000);
	  temp_str_data[2]=48+((val%1000)/100);
	  temp_str_data[3]=48+((val%100)/10);
	  temp_str_data[4]=48+(val%10);
}

void main(void){
		TMOD=0x10;
	  TH1= 0x00;
	  TL1= 0x00;
	//start timer1
	TR1=1;
	//execute program
a1 = a/10;
a0 = a % 10;
b1 = b/10;
b0 = b % 10;
c0 = a0*b0;
c1 = a0*b1;
c2 = a1*b0;
c3 = a1*b1;
c = c0 + (c1 + c2)*10 + c3*100;
  //stop timer
	TR1=0;
	count=((TH1 & 0x00ff) << 8) | (TL1 & 0x00ff); 
	count=count*0.5;
	//convert to string
	int_to_string9(c,str);
	int_to_string5(count,str2);
	
	//display 
  lcd_init();
	lcd_cmd(0x80);
	msdelay(4);
	lcd_write_string("Prod1=");	
	lcd_write_string(str);	
	lcd_cmd(0xC0);													//Move cursor to 2nd line of LCD
	msdelay(4);
	lcd_write_string("Time1=");
	lcd_write_string(str2);
	lcd_write_string("us");
	while(1);
}